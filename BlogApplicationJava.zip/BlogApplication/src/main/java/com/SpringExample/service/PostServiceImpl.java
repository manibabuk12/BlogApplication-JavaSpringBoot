package com.SpringExample.service;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.SpringExample.entity.Post;
import com.SpringExample.repository.PostReposititory;

import jakarta.persistence.EntityNotFoundException;

@Service
public class PostServiceImpl implements PostService {

    @Autowired
    private PostReposititory postReposititory;

    public Post savePost(Post post) {
        post.setLikeCount(0);
        post.setViewCount(0);
        post.setDate(new Date());

        return postReposititory.save(post);
    }

    public List<Post> getAllPosts() {
        return postReposititory.findAll();
    }

    public Post getPostById(Long postId) {
        Optional<Post> optionalpost = postReposititory.findById(postId);

        if (optionalpost.isPresent()) {
            Post post = optionalpost.get();
            post.setViewCount(post.getViewCount() + 1);

            return postReposititory.save(post);
        } else {
            throw new EntityNotFoundException("Post not Found");
        }
    }

    public void likePost(Long postId) {
        Optional<Post> optional = postReposititory.findById(postId);
        if (optional.isPresent()) {
            Post post = optional.get();
            post.setLikeCount(post.getLikeCount() + 1);
            postReposititory.save(post);
        } else {
            throw new EntityNotFoundException("Post not found with Id" + postId);
        }
    }

    public List<Post> searchByName(String name) {
        return postReposititory.findAllByNameContaining(name);
    }
}
