package com.SpringExample.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.SpringExample.entity.Post;

public interface PostReposititory extends JpaRepository<Post, Long> {

    List<Post> findAllByNameContaining(String name);

}
