package com.SpringExample.entity;

public @interface NotEmpty {

    String message();

}
